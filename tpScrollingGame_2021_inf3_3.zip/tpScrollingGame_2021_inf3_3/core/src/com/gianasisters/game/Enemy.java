package com.gianasisters.game;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

public abstract class Enemy{
	
	private Vector2 position;
	private EnemyType enemy;
	private Map map;
	private Rectangle hittableArea;
	
	public abstract void render(SpriteBatch batch);

	public Enemy(Vector2 position, EnemyType enemy, Map map) {
		super();
		this.position = position;
		this.enemy = enemy;
		this.map = map;
		hittableArea = new Rectangle();
		hittableArea.x = position.x;
		hittableArea.y = position.y + 40;
		hittableArea.width = 32;
		hittableArea.height = 1;
		
	}
	
	public Vector2 getPosition() {
		return position;
	}
	
	public boolean collideWithPlayer(Rectangle hitboxPlayer) {
		if(new Rectangle(position.x, position.y, getWidth(), getHeight()).overlaps(hitboxPlayer) && collideWithDeath(hitboxPlayer) == false) {
			return true;
		}
		return false;
	}
	
	public boolean collideWithDeath(Rectangle hitboxPlayer) {
		if(hittableArea.overlaps(hitboxPlayer)) {
			return true;
		}
		return false;
	}
	
	
	public abstract void update(float delta);
	
	public void XmovementsEnemy(float x) {
		float newX = this.position.x + x;
		if(!map.CollideWithMap(newX, position.y, getWidth(), getHeight())) {
			this.position.x = newX;
		}
		hittableArea.x = position.x;
	}
	
	public int getWidth() {
		return enemy.getWidth();
	}
	
	public int getHeight() {
		return enemy.getHeight();
	}
	
	public Rectangle getHittableArea() {
		return hittableArea;
	}
	
}
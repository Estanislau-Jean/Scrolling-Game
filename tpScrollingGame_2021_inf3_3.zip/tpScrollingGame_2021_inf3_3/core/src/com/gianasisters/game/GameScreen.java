package com.gianasisters.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class GameScreen extends Screen{
	private Map mapa;
	private Hud hud;
	private SpriteBatch batch;
	private OrthographicCamera camera;
	private Music GameMusic;
	
	public GameScreen(SpriteBatch batch, OrthographicCamera camera) {
		this.batch = batch;
		this.camera = camera;
		hud = new Hud();
		mapa = new tiledGameMap();
		GameMusic = Gdx.audio.newMusic(Gdx.files.internal("musica-de-fundo.mp3"));
	}

	@Override
	public void drawScreen() {
		mapa.update(Gdx.graphics.getDeltaTime());
		mapa.render(camera, batch);
		hud.render(batch, Gdx.graphics.getDeltaTime(), camera, mapa.getPoints(), mapa.getPlayerLife());
		mapa.CameraMovement(camera);
		mapa.FallonAbyss();
	}

	@Override
	public void playScreen() {
		GameMusic.setVolume((float) 0.2);
		GameMusic.setLooping(true);
		GameMusic.play();
		
	}
	
	

	@Override
	public void stopScreen() {
		GameMusic.stop();
		
	}

	@Override
	public Texture getImg() {
		return null;
	}

	@Override
	public Music getMusic() {
		return null;
	}

	@Override
	public Map getMap() {
		return mapa;
	}

	@Override
	public Hud getHud() {
		// TODO Auto-generated method stub
		return hud;
	}

	@Override
	public boolean setCamera(boolean restart) {
		return false;
		
	}

	@Override
	public boolean MusicTest() {
		if(mapa.getPowerUpCatch()) {
			return true;
		}
		return false;
	}
}
package com.gianasisters.game;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Hud{
	
	private int Timer;
	private float lastCount = 0;
	private int score;
	
	private BitmapFont font;
	
	
	public Hud() {
		Timer = 150;
		score = 0;
		font = new BitmapFont();
		font.setColor(Color.BLACK);
		font.getData().setScale(2, 2);		
	}
	
	public void render(SpriteBatch batch, float deltaTime, OrthographicCamera camera, int points, int life) {
		font.draw(batch, String.format("KIPO"), -390 + camera.position.x, 500);
		font.draw(batch, String.format("%06d", score), -400 + camera.position.x, 450);
		
		font.draw(batch, String.format("STAGE"), 100 + camera.position.x, 500);
		font.draw(batch, String.format("1 - 1"), 120 + camera.position.x, 450);
		
		font.draw(batch, String.format("LIFE"), -160 + camera.position.x, 500);
		font.draw(batch, String.format("%02d", life), -150 + camera.position.x, 450);
		
		font.draw(batch, String.format("TIME"), 320 + camera.position.x, 500);
		font.draw(batch, String.format("%03d", Timer), 330 + camera.position.x, 450);
		
		update(deltaTime, points);
	}
	
	public void update(float delta, int points) {
		lastCount += delta;
		
		if(lastCount >= 1) {
			Timer--;
			lastCount = 0;
		}
		
		score = points;
		
	}
	
	public int getTimer() {
		return Timer;
	}
	
	public void setTimer(int timer) {
		Timer = timer;
	}
	 
}
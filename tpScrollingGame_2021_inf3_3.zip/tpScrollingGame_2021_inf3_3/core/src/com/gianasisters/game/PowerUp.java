package com.gianasisters.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;

public class PowerUp implements BlocksBroken{
	
	private Texture power;
	private boolean collidable = true;
	private Rectangle hitbox;
	
	public PowerUp(float x, float y) {
		hitbox = new Rectangle();
		power = new Texture("powerup.png");
		hitbox.width = 32;
		hitbox.height = 32;
		hitbox.x = x;
		hitbox.y = y;
	}
	

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void render(SpriteBatch batch) {
		batch.draw(power, hitbox.x, hitbox.y, hitbox.width, hitbox.height);
		
	}

	@Override
	public boolean collide(Rectangle hitbox) {
		if(collidable == true && this.hitbox.overlaps(hitbox)) {
			return true;
		}
		return false;
	}
	
}
package com.gianasisters.game;

public enum EnemyType{
	
	FROG("Frog", 32, 32);
	
	private String id;
	private int width;
	private int height;
	
	private EnemyType(String id, int width, int height) {
		this.id = id;
		this.width = width;
		this.height = height;
	}

	public String getId() {
		return id;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}
}


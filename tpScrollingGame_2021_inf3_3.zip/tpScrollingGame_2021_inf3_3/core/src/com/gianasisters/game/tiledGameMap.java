package com.gianasisters.game;

import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTile;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer.Cell;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;

public class tiledGameMap extends Map{
	
	TiledMap tiledmap;
	OrthogonalTiledMapRenderer renderer;
	
	public tiledGameMap() {
		tiledmap = new TmxMapLoader().load("Kipo.tmx");
		renderer = new OrthogonalTiledMapRenderer(tiledmap);
		
	}
	

	@Override
	public TilesType getTileTypeByCoordinate(int layer, int col, int row) {
		Cell cell = ((TiledMapTileLayer) tiledmap.getLayers().get(layer)).getCell(col, row);
		
		if (cell != null) {
			TiledMapTile tile = cell.getTile();
			if(tile != null) {
				int id = tile.getId();
				return TilesType.getTileTypeById(id);
			}
		}
		
		return null;
	}
	
	@Override
	public void render(OrthographicCamera camera, SpriteBatch batch) {
		renderer.setView(camera);
		renderer.render();
		batch.setProjectionMatrix(camera.combined);
		super.render(camera, batch);
	}

	@Override
	public void update(float delta) {
		super.update(delta);
		
	}


	@Override
	public void dispose() {
		tiledmap.dispose();
		
	}


	@Override
	public int getWidth() {
		return ((TiledMapTileLayer) tiledmap.getLayers().get(0)).getWidth();
	}


	@Override
	public int getHeight() {
		return ((TiledMapTileLayer) tiledmap.getLayers().get(0)).getHeight();
	}


	@Override
	public int getLayers() {
		return tiledmap.getLayers().getCount();
	}
	
}
package com.gianasisters.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class MenuScreen extends Screen{
	private Texture img;
	private Music MenuMusic;
	private SpriteBatch batch;
	private OrthographicCamera camera;
	
	public MenuScreen(SpriteBatch batch, OrthographicCamera camera) {
		img = new Texture("menu.png");
		MenuMusic = Gdx.audio.newMusic(Gdx.files.internal("musica-de-fundo.mp3"));
		this.batch = batch;
		this.camera = camera;
	}
	
	public Texture getImg() {
		return img;
	}
	
	public Music getMusic() {
		return MenuMusic;
	}
	
	public void drawScreen() {
		batch.draw(this.getImg(), -450 + camera.position.x, 0);
	}
	
	public void playScreen() {
		this.getMusic().setLooping(true);
		this.getMusic().setVolume((float) 0.1);
		this.getMusic().play();
	}
	
	public void stopScreen() {
		this.getMusic().stop();
	}

	@Override
	public Map getMap() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Hud getHud() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean setCamera(boolean restart) {
		if(restart) {
			return true;
		}
		return false;
	}

	@Override
	public boolean MusicTest() {
		// TODO Auto-generated method stub
		return false;
	}
}
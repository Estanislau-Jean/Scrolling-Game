package com.gianasisters.game;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;

public interface BlocksBroken{
	public void update();
	public void render(SpriteBatch batch);
	public boolean collide(Rectangle hitbox);
}
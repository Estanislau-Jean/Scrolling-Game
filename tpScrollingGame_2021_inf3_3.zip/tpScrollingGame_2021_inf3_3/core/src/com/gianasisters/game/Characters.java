package com.gianasisters.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;

public abstract class Characters{
	
	private Vector2 position;
	private CharactersType characters;
	private float VelocityAir = 0;
	private Map map;
	private int life = 3;
	protected boolean grounded = false;
	
	public int getLife() {
		return life;
	}
	
	public void setLife(int life) {
		this.life = life;
	}
	
	public Characters(Map map, CharactersType characters, float x, float y) {
		super();
		this.characters = characters;
		this.position = new Vector2(x, y);
		this.map = map;
	}
	
	
	
	public boolean CollideWithCastle(float x) {
		if(x >= 1180) {
			return true;
		}
		return false;
	}
	public void update(float delta, float gravity) {
		 float newY = position.y;
		 
		 this.VelocityAir += gravity * delta *getWeight();
		 newY += this.VelocityAir * delta;
		 
		 if(map.CollideWithMap(position.x, newY, getWidth(), getHeight())) {
			 if(this.VelocityAir < 0){
				 this.position.y = (float) Math.floor(position.y);
				 grounded = true;
			 }
			 this.VelocityAir = 0;
		 }
		 else {
			
			 this.position.y = newY;
			 grounded = false;
		 }
	}
	
	public abstract void render(SpriteBatch batch);
	
	public void Xmovements(float x) {
		float newX = this.position.x + x;
		if(!map.CollideWithMap(newX, position.y, getWidth(), getHeight())) {
			this.position.x = newX;
		}
	}

	public Vector2 getPosition() {
		return position;
	}
	
	public void setX(int x) {
		position.x = x;
	}
	
	public void setY(int y) {
		position.y = y;
	}

	public CharactersType getCharacters() {
		return characters;
	}

	public float getVelocityAir() {
		return VelocityAir;
	}
	
	public void setVelocityAir(float velocity) {
		VelocityAir = velocity;
	}

	public boolean isGrounded() {
		return grounded;
	}
	
	public int getWidth() {
		return characters.getWidth();
	}
	
	public int getHeight() {
		return characters.getHeight();
	}

	public float getWeight() {
		return characters.getWeight();
	}
	
	public abstract void setRightTexture(Texture texture, Texture texture2);
	
	public abstract void setLeftTexture(Texture texture, Texture texture2);
}
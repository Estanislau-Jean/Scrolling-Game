package com.gianasisters.game;

import java.util.HashMap;

public enum TilesType{
	
	Castle(375, true, "Castle", 0),
	Ground(284, true, "Ground", 0);
	
	public static int TILE_SIZE = 32;
	private int id;
	private boolean collidable;
	private String name;
	private int life;
	
	private TilesType(int id, boolean collidable, String name, int life) {
		this.id = id;
		this.collidable = collidable;
		this.name = name;
		this.life = life;
	}

	public int getId() {
		return id;
	}

	public boolean isCollidable() {
		return collidable;
	}

	public String getName() {
		return name;
	}

	public int getLife() {
		return life;
	}
	
	public static TilesType getTileTypeById(int id) {
		return tileMap.get(id);
	}
	
	private static HashMap<Integer, TilesType> tileMap;
	
	static {
		tileMap = new HashMap<Integer, TilesType>();
		for(TilesType tiletype : TilesType.values()) {
			tileMap.put(tiletype.getId(), tiletype);
		}
	}
}
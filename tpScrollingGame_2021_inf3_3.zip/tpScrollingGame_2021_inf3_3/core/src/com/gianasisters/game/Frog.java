package com.gianasisters.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;

public class Frog extends Enemy{
	
	private int speed = 1;
	private Texture img;
	private Texture movements[];
	private float countmovement = 0;
	private float alternatemovement = 0;
	private int movementTimer = 0;

	public Frog(Vector2 position, Map map) {
		super(position, EnemyType.FROG, map);
		movements = new Texture[2];
		img = new Texture("mcSapao.png");
		movements[0] = new Texture("sprite_sapo.png");
		movements[1] = new Texture("sprite_sapo1.png");
	}

	@Override
	public void render(SpriteBatch batch) {
		batch.draw(img, getPosition().x, getPosition().y, getWidth(), getHeight());
		
	}

	@Override
	public void update(float delta) {
		countmovement += delta;
		alternatemovement += delta * 4;
		
		if(countmovement < 2 && countmovement >= 0) {
			XmovementsEnemy(speed);
			if(alternatemovement >= 1) {
				movementTimer++;
				alternatemovement = 0;
			}if(movementTimer <= 1 && movementTimer > 0 ){
				
				img = movements[1];
				
			}if(movementTimer >= 2 && movementTimer < 3){
				
				img = movements[0];
				
			}else if(movementTimer >= 2) {
				movementTimer = 0;
			}
		}
		
		if(countmovement >= 2 && countmovement < 4) {
			XmovementsEnemy(-speed);
			
			if(alternatemovement >= 1) {
				movementTimer++;
				alternatemovement = 0;
			}if(movementTimer <= 1 && movementTimer > 0 ){
				
				img = movements[0];
				
			}if(movementTimer >= 2 && movementTimer < 3){
				
				img = movements[1];
				
			}else if(movementTimer >= 2) {
				movementTimer = 0;
			}
		}
		
		if(countmovement >= 4) {
			countmovement = 0;
		}
	}
	
}
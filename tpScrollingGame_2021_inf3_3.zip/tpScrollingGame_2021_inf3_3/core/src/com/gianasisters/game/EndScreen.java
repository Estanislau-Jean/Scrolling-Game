package com.gianasisters.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class EndScreen extends Screen{
	private Texture[] img;
	private Music[] EndMusic;
	private SpriteBatch batch;
	private int indice;
	private OrthographicCamera camera;
	
	public EndScreen(SpriteBatch batch, int indice, OrthographicCamera camera) {
		img = new Texture[2];
		EndMusic = new Music[2];
		this.batch = batch;
		this.indice = indice;
		img[0] = new Texture("perdeu.png");
		img[1] = new Texture("venceu.png");
		EndMusic[0] = Gdx.audio.newMusic(Gdx.files.internal("triste.mp3"));
		EndMusic[1] = Gdx.audio.newMusic(Gdx.files.internal("ganhou.mp3"));
		this.camera = camera;
	}
	
	public Texture getImgByIndice() {
		return img[indice];
	}
	
	public Music getMusic() {
		return EndMusic[indice];
	}
	
	public void drawScreen() {
		batch.draw(this.getImgByIndice(), -250, 0);
		camera.position.x = 0;
		camera.update();
	}
	
	public void playScreen() {
		this.getMusic().setLooping(true);
		this.getMusic().setVolume((float) 0.2);
		this.getMusic().play();
	}
	
	public void stopScreen() {
		this.getMusic().stop();
	}

	@Override
	public Texture getImg() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map getMap() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Hud getHud() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean setCamera(boolean restart) {
		return false;
		
	}

	@Override
	public boolean MusicTest() {
		// TODO Auto-generated method stub
		return false;
	}
}
package com.gianasisters.game;

import java.util.ArrayList;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.ScreenUtils;

public class GreatGianaSistersGame extends ApplicationAdapter {
	private SpriteBatch batch;
	private OrthographicCamera camera;
	private boolean startgame = false;
	private ArrayList<Screen> screens;
	private boolean restart = false;
	
	@Override
	public void create () {
		screens = new ArrayList<Screen>();
		batch = new SpriteBatch();
		camera = new OrthographicCamera();
		camera.setToOrtho(false, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
		camera.update();
		screens.add(new MenuScreen(batch, camera));
		screens.add(new GameScreen(batch, camera));
		screens.add(new EndScreen(batch, 0, camera));
		screens.add(new EndScreen(batch, 1, camera));
	}

	@Override
	public void render () {
		ScreenUtils.clear(Color.SKY);
		batch.begin();
		StartGame();
		if(startgame == false) {
			ScreenUtils.clear(Color.SKY);
			screens.get(0).drawScreen();
			screens.get(0).playScreen();
		}else if(restart == true && startgame == false){
			ScreenUtils.clear(Color.SKY);
			screens.get(0).drawScreen();
			screens.get(0).playScreen();
		}else {
			ScreenUtils.clear(Color.SKY);
			screens.get(1).drawScreen();
			if(screens.get(1).MusicTest()) {
				screens.get(0).stopScreen();
			} else {
				screens.get(0).playScreen();
			}
			EndGame();
		}
		batch.end();
	}
	
	@Override
	public void dispose () {
		batch.dispose();
	}
	
	public void StartGame() {
		if(Gdx.input.isTouched()) {
	         Vector2 touchPos = new Vector2();
	         touchPos.set(Gdx.input.getX(), Gdx.input.getY());
	      }
		
		if(Gdx.input.isKeyPressed(Keys.ENTER)) {
			startgame = true;
		}
	}
	
	public void EndGame() {
		if(screens.get(1).getHud().getTimer() <= 0) {
			ScreenUtils.clear(0, 0, 0, 0);
			screens.get(2).drawScreen();
			screens.get(0).stopScreen();
			screens.get(2).playScreen();
			
		}
		
		if(screens.get(1).getMap().getWinner()) {
			ScreenUtils.clear(0, 0, 0, 0);
			screens.get(3).drawScreen();
			screens.get(0).stopScreen();
			screens.get(3).playScreen();
		}
		
		if(screens.get(1).getMap().getPlayerLife() == 0) {
			ScreenUtils.clear(0, 0, 0, 0);
			screens.get(2).drawScreen();
			screens.get(0).stopScreen();
			screens.get(2).playScreen();
		}
		
		RestartGame();
		
	}
	
	public void RestartGame() {
		if(Gdx.input.isTouched()) {
	         Vector2 touchPos = new Vector2();
	         touchPos.set(Gdx.input.getX(), Gdx.input.getY());
	      }
		
		if(Gdx.input.isKeyPressed(Keys.R)){
			restart = true;
			startgame = false;
			screens.get(0).stopScreen();
			screens.get(2).stopScreen();
			screens.get(3).stopScreen();
			screens.get(1).getMap().setPlayerLife(3);
			screens.get(1).getMap().setWinner(false);
			screens.get(1).getHud().setTimer(150);
			screens.get(1).getMap().setPoints(0);
			screens.get(0).setCamera(restart);
			screens.get(1).getMap().resetMap();
		}
	}	
}

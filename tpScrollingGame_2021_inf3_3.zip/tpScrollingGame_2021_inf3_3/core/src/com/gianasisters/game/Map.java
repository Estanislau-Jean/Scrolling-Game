package com.gianasisters.game;

import java.util.ArrayList;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

public abstract class Map{
	
	protected ArrayList<Characters> characters;
	private ArrayList<CoinBlock> coinblock;
	private ArrayList<Enemy> enemy;
	private ArrayList<PowerUp> powerup;
	private int playerLife = 3;
	private int points = 0;
	private boolean winner = false;
	private Sound crystalCatch;
	private Sound enemyDeath;
	private Sound playerHit;
	private Music PowerUpMusic;
	private boolean powerUpCatch = false;
	private float PowerCont = 0;
	private int PowerTimer = 800;
	private boolean lifeCantDecrease = false;
	private float delta;
	
	
	 public Map() {
		 characters = new ArrayList<Characters>();
		 coinblock = new ArrayList<CoinBlock>();		 
		 enemy = new ArrayList<Enemy>();
		 powerup = new ArrayList<PowerUp>();
		 
		 powerup.add(new PowerUp(365, 240));
		 enemy.add(new Frog(new Vector2(100, 65), this));
		 enemy.add(new Frog(new Vector2(500, 225), this));
		 enemy.add(new Frog(new Vector2(800, 65), this));
		 
		 characters.add(new Player(this, (float)50, (float)100));
		 
		 coinblock.add(new CoinBlock(512, 300));
		 coinblock.add(new CoinBlock(544, 300));
		 coinblock.add(new CoinBlock(576, 300));
		 coinblock.add(new CoinBlock(608, 300));
		 
		 coinblock.add(new CoinBlock(322, 200));
		 coinblock.add(new CoinBlock(354, 200));
		 coinblock.add(new CoinBlock(386, 200));
		 coinblock.add(new CoinBlock(418, 200));
		 
		 coinblock.add(new CoinBlock(800, 100));
		 coinblock.add(new CoinBlock(832, 100));
		 coinblock.add(new CoinBlock(864, 100));
		 coinblock.add(new CoinBlock(896, 100));
		 
		 crystalCatch = Gdx.audio.newSound(Gdx.files.internal("pegar-pontos-.wav"));
		 enemyDeath = Gdx.audio.newSound(Gdx.files.internal("Matar-inimigo.wav"));
		 playerHit = Gdx.audio.newSound(Gdx.files.internal("morreu.wav"));
		 PowerUpMusic =  Gdx.audio.newMusic(Gdx.files.internal("powerup.mp3"));
		 PowerUpMusic.setVolume((float) 0.5);
	 }
	
	public TilesType getTileTypeByLocation(int layer, float x, float y) {
		return this.getTileTypeByCoordinate(layer, (int) (x / TilesType.TILE_SIZE), (int) (y / TilesType.TILE_SIZE));
	}
	
	public abstract TilesType getTileTypeByCoordinate(int layer, int col, int row);
	
	public void render(OrthographicCamera camera, SpriteBatch batch) {
		//shape.setProjectionMatrix(camera.combined);
		
		for(Characters character : characters) {
			character.render(batch);
			for(int i = 0; i < enemy.size(); i++){
				if(enemy.get(i).collideWithDeath(new Rectangle(character.getPosition().x, character.getPosition().y, character.getWidth(), character.getHeight()))) {
					enemy.remove(i);
					points += 100;
					enemyDeath.play((float) 0.1);
				}else if(enemy.get(i).collideWithPlayer(new Rectangle(character.getPosition().x, character.getPosition().y, character.getWidth(), character.getHeight())) && lifeCantDecrease == false){
					character.setLife(character.getLife() - 1);
					playerLife = character.getLife();
					character.setX(50);
					character.setY(100);
					playerHit.play((float) 0.1);
				}else {
					enemy.get(i).render(batch);
				}
			}
			if(character.CollideWithCastle(character.getPosition().x)){
				winner = true;
				character.setX(50);
				character.setY(100);
			}
			for(int i = 0; i < coinblock.size(); i++){
				if(coinblock.get(i).collide(new Rectangle(character.getPosition().x, character.getPosition().y, character.getWidth(), character.getHeight()))) {
					coinblock.remove(i);
					crystalCatch.play((float) 0.2);
					points += 45;
				}else {
				
					coinblock.get(i).render(batch);
				}
			}
			
			for(int i = 0; i < powerup.size(); i++) {
				if(powerup.get(i).collide(new Rectangle(character.getPosition().x, character.getPosition().y, character.getWidth(), character.getHeight()))){
					powerup.remove(i);
					powerUpCatch = true;
				
				}else {
					powerup.get(i).render(batch);
				}
			}
		}
	}
	
	public void update(float delta) {
		this.delta = delta;
		for(Characters character : characters) {
			character.update(delta, -9.8f);
		}
		
		for(Enemy e : enemy) {
			e.update(delta);
		}
		
		for(CoinBlock coin : coinblock) {
			coin.update();
		}
		
		if(powerUpCatch) {
			PowerCont += delta;
			if(PowerCont >= 1) {
				PowerTimer = PowerTimer - 1;
			}
			
			if(PowerTimer >= 0) {
				PowerUpMusic.play();
				for(int i = 0; i < characters.size(); i++) {
					characters.get(i).setLeftTexture(new Texture("sprite_powerup4.png"), new Texture("sprite_powerup5.png"));
					characters.get(i).setRightTexture(new Texture("sprite_powerup1.png"), new Texture("sprite_powerup2.png"));
				}
				lifeCantDecrease = true;
			}else {
				for(int i = 0; i < characters.size(); i++) {
					characters.get(i).setLeftTexture(new Texture("sprite_kipo4.png"), new Texture("sprite_kipo5.png"));
					characters.get(i).setRightTexture(new Texture("sprite_kipo1.png"), new Texture("sprite_kipo2.png"));
				}
				PowerUpMusic.stop();
				lifeCantDecrease = false;
				powerUpCatch = false;
			}
		}
		else {
			PowerTimer = 800;
		}
	}
	
	public boolean CollideWithMap(float x, float y, int width, int height) {
		if(x < 0 || y < 0 || x + width > (1280) || y + height >  (800)) {
			return true;
		}
		
		for(int row = (int) (y / TilesType.TILE_SIZE); row < Math.ceil((y + height) / TilesType.TILE_SIZE); row++){
			for(int col = (int) (x / TilesType.TILE_SIZE); col < Math.ceil((x + width) / TilesType.TILE_SIZE); col++) {
				for(int layer = 0; layer < getLayers(); layer++) {
					TilesType type = getTileTypeByCoordinate(layer, col, row);
					if(type != null && type.isCollidable()) {
						return true;
					}
				}
			}
		}
		return false;
	}
	
	public abstract void dispose();
	
	public abstract int getWidth();
	public abstract int getHeight();
	public abstract int getLayers();
	
	public void StopScreenMusic(Music background) {
		background.stop();
	}
	
	public void ContinueScreenMusic(Music background) {
		background.play();
	}
	
	public void CameraMovement(OrthographicCamera camera) {
		for(Characters character : characters) {
			camera.position.x = character.getPosition().x;
			camera.update();
		}
	}
	
	public int getPoints() {
		return points;
	}
	
	public boolean getWinner() {
		return winner;
	}
	
	public boolean FallonAbyss() {
		for(Characters character : characters) {
			if(character.getPosition().y == 0 && lifeCantDecrease == false) {
				character.setLife(character.getLife() - 1);
				playerLife = character.getLife();
				character.setX(50);
				character.setY(100);
				playerHit.play((float) 0.1);
				return true;
			}
		}
		return false;
	}
	
	public int getPlayerLife() {
		return playerLife;
	}
	
	public void setPlayerLife(int life) {
		playerLife = life;
		for(Characters character : characters) {
			character.setLife(life);
		}
	}
	
	public void setWinner(boolean winner) {
		this.winner = winner;
	}
	
	public void setPoints(int points) {
		this.points = points;
	}
	
	public void resetMap() {
		for(int i = 0; i < enemy.size(); i++){
			enemy.remove(i);
		}
		for(int i = 0; i < coinblock.size(); i++){
			coinblock.remove(i);
		}
		
		for(int i = 0; i < powerup.size(); i++) {
			powerup.remove(i);
		}
		 coinblock.add(new CoinBlock(512, 300));
		 coinblock.add(new CoinBlock(544, 300));
		 coinblock.add(new CoinBlock(576, 300));
		 coinblock.add(new CoinBlock(608, 300));
		 
		 coinblock.add(new CoinBlock(322, 200));
		 coinblock.add(new CoinBlock(354, 200));
		 coinblock.add(new CoinBlock(386, 200));
		 coinblock.add(new CoinBlock(418, 200));
		 
		 coinblock.add(new CoinBlock(800, 100));
		 coinblock.add(new CoinBlock(832, 100));
		 coinblock.add(new CoinBlock(864, 100));
		 coinblock.add(new CoinBlock(896, 100));
		 
		 powerup.add(new PowerUp(365, 240));
		 
		 update(delta);
		 
		 if(enemy.size() == 0) {
			 enemy.add(new Frog(new Vector2(100, 65), this));
			 enemy.add(new Frog(new Vector2(500, 225), this));
			 enemy.add(new Frog(new Vector2(800, 65), this));
		 }
	}
	
	public boolean getPowerUpCatch() {
		return powerUpCatch;
	}
}
package com.gianasisters.game;

import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.Texture;

public abstract class Screen{
	public abstract void drawScreen();
	public abstract void playScreen();
	public abstract void stopScreen();
	public abstract Texture getImg();
	public abstract Music getMusic();
	public abstract Map getMap();
	public abstract Hud getHud();
	public abstract boolean setCamera(boolean restart);
	public abstract boolean MusicTest();
}
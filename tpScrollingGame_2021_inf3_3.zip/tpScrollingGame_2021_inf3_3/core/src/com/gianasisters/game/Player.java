package com.gianasisters.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Player extends Characters{
	
	private int speed = 80;
	private int jump_speed = 5;
	private Texture img;
	private Texture[] RightWalk;
	private Texture[] LeftWalk;
	private float delayRight = 0;
	private float delayLeft = 0;
	private int LeftTimer = 0;
	private int RightTimer = 0;

	public Player(Map map, float x, float y) {
		super(map, CharactersType.PLAYER, x, y);
		img = new Texture("sprite_0.png");
		RightWalk = new Texture[2];
		RightWalk[0] = new Texture("sprite_kipo1.png");
		RightWalk[1] = new Texture("sprite_kipo2.png");
		LeftWalk = new Texture[2];
		LeftWalk[0] = new Texture("sprite_kipo4.png");
		LeftWalk[1] = new Texture("sprite_kipo5.png");
		
	}
	
	@Override
	public void update(float deltaTime, float gravity) {
		if(Gdx.input.isKeyPressed(Keys.SPACE) && grounded) {
			this.setVelocityAir(this.getVelocityAir() + jump_speed * getWeight());
			RightTimer = 0;
			LeftTimer = 0;
		}else if(Gdx.input.isKeyPressed(Keys.SPACE) && !grounded) {
			this.setVelocityAir(this.getVelocityAir() + jump_speed * getWeight() * deltaTime);
			RightTimer = 0;
			LeftTimer = 0;
		}
		
		super.update(deltaTime, gravity);
		if(Gdx.input.isKeyPressed(Keys.LEFT)) {
			RightTimer = 0;
			delayLeft += deltaTime * 4;
			Xmovements(deltaTime * -speed);
			if(delayLeft >= 1) {
				LeftTimer += 1;
				delayLeft = 0;
			}if(LeftTimer <= 1 && LeftTimer > 0 ){
				
				img = LeftWalk[1];
				
			}if(LeftTimer >= 2 && LeftTimer < 3){
				
				img = LeftWalk[0];
				
			}else if(LeftTimer >= 2) {
				LeftTimer = 0;
			}
		}
		
		if(Gdx.input.isKeyPressed(Keys.RIGHT)) {
			delayRight += deltaTime * 4;
			LeftTimer = 0;
			Xmovements(deltaTime * speed);
			if(delayRight >= 1) {
				RightTimer += 1;
				delayRight = 0;
			}if(RightTimer <= 1 && RightTimer > 0){
				
				img = RightWalk[1];
				
			}if(RightTimer >= 2 && RightTimer < 3){
				
				img = RightWalk[0];
				
			}else if(RightTimer >= 2) {
				RightTimer = 0;
			}
		}
	}
	@Override
	public void render(SpriteBatch batch) {
		batch.draw(img, getPosition().x, getPosition().y, getWidth(), getHeight());
		
	}

	@Override
	public void setRightTexture(Texture texture, Texture texture2) {
		RightWalk[0] = texture;
		RightWalk[1] = texture2;
	}

	@Override
	public void setLeftTexture(Texture texture,Texture texture2) {
		LeftWalk[0] = texture;
		LeftWalk[1] = texture2;
	}
}
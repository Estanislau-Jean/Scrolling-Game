package com.gianasisters.game;

public enum CharactersType{
	PLAYER("player", 32, 32, 40);
	
	private String id;
	private int width, height;
	private float weight;
	
	private CharactersType(String id, int width, int height, float weight) {
		this.id = id;
		this.width = width;
		this.height = height;
		this.weight = weight;
	}

	public float getWeight() {
		return weight;
	}

	public void setWeight(float weight) {
		this.weight = weight;
	}

	public String getId() {
		return id;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}
	
	
	
	
}
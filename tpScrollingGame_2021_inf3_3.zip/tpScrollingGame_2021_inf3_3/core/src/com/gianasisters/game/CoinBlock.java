package com.gianasisters.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;

public class CoinBlock implements BlocksBroken{
	
	private Texture block;
	private int life = 1;
	private boolean collidable = true;
	private Rectangle hitbox;
	
	public CoinBlock(float x, float y) {
		hitbox = new Rectangle();
		block = new Texture("queijo (1).png");
		hitbox.width = 32;
		hitbox.height = 32;
		hitbox.x = x;
		hitbox.y = y;
		
		
	}
	
	@Override
	public void update() {
		
	}
	
	

	public boolean isCollidable() {
		return collidable;
	}

	public void setCollidable(boolean collidable) {
		this.collidable = collidable;
	}

	public float getWidth() {
		return hitbox.getWidth();
	}

	public float getHeight() {
		return hitbox.getHeight();
	}

	public int getLife() {
		return life;
	}

	@Override
	public void render(SpriteBatch batch) {
		batch.draw(block, hitbox.x, hitbox.y, hitbox.width, hitbox.height);
	}

	@Override
	public boolean collide(Rectangle hitbox) {
		if(collidable == true && this.hitbox.overlaps(hitbox)) {
			life--;
			return true;
		}
		return false;
	}
}
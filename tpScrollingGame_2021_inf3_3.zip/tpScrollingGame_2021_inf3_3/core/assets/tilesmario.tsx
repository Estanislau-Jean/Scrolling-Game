<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.1" name="tilesmario" tilewidth="32" tileheight="32" tilecount="144" columns="16" objectalignment="center">
 <image source="tilesmario.png" width="512" height="300"/>
</tileset>

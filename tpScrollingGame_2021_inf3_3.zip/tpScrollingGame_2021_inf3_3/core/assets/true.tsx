<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.1" name="true" tilewidth="32" tileheight="32" tilecount="740" columns="37">
 <image source="truebackground.jpg" width="1200" height="659"/>
</tileset>

<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.1" name="mario" tilewidth="32" tileheight="32" tilecount="250" columns="25" objectalignment="center">
 <image source="Downloads/NES - Super Mario Bros - Tileset.png" width="821" height="347"/>
</tileset>

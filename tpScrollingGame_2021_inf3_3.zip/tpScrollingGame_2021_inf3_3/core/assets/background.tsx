<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.1" name="background" tilewidth="32" tileheight="32" tilecount="405" columns="27">
 <transformations hflip="1" vflip="0" rotate="0" preferuntransformed="0"/>
 <image source="KipoBackground.png" width="885" height="500"/>
</tileset>

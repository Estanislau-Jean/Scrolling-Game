package com.gianasisters.game.desktop;

import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.gianasisters.game.GreatGianaSistersGame;

public class DesktopLauncher {
	public static void main (String[] arg) {
		LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
		config.title = "Kipo Adventures";
		config.height = 500;
		config.width = 800;
		config.resizable = false;
		new LwjglApplication(new GreatGianaSistersGame(), config);
	}
}
